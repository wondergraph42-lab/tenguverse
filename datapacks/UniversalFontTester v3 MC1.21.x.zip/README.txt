Universal Font Tester Datapack - v3

Instantly preview and test Minecraft fonts in-game. This datapack is built for creators, resource-pack artists, and players who want a fast way to inspect readability, spacing, accents, symbols, multilingual support, and UI behavior.

Overview
Universal Font Tester provides focused preview commands for the most useful character groups:
- Basic Latin and punctuation
- Extended Latin accents and ligatures
- Greek uppercase, lowercase, and accented letters
- Cyrillic alphabet with extra regional letters
- Symbols, arrows, operators, and UI-friendly glyphs
- Width and ambiguity tests for narrow and wide characters
- UI-focused labels, counters, buttons, and status text

Commands
/function fonttester:help              Opens the clickable command menu
/function fonttester:show/ascii        Shows basic Latin, digits, punctuation, and a sample sentence
/function fonttester:show/latin        Shows extended Latin characters and accented sample words
/function fonttester:show/greek        Shows Greek uppercase, lowercase, and accented forms
/function fonttester:show/cyrillic     Shows Cyrillic uppercase, lowercase, and common regional letters
/function fonttester:show/symbols      Shows symbols, arrows, and mathematical operators
/function fonttester:show/width_test   Shows narrow, wide, and easily-confused characters
/function fonttester:show/ui_test      Shows HUD, menu, button, and number samples
/function fonttester:full              Runs every on-screen preview section in sequence

What this helps you test
- Font readability in chat
- Character width and spacing
- Accent placement and multilingual coverage
- Symbol availability for UI packs
- Visual consistency across multiple glyph groups
- Legibility of menus, HUD labels, counters, and timers

Notes
- This datapack only displays text. It does not modify fonts by itself.
- Glyph visibility depends on the active resource pack.
- Place your font resource pack at the top of the list for the most accurate preview.
- A clickable help message appears automatically on /reload through minecraft:load.

Credits
Created by LevelsFR
Part of the Our Story Collection
Hosted with support from BisectHosting

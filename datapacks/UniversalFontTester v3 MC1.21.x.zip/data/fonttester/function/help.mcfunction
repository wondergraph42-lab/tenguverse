tellraw @s {"text":"===========================================","color":"white"}
tellraw @s [{"text":" Universal Font Tester v3 ","color":"gold","bold":true},{"text":"- Command Menu","color":"white"}]
tellraw @s {"text":"===========================================","color":"white"}
tellraw @s {"text":"Click a command to preview that character group.","color":"gray","italic":true}
tellraw @s {"text":""}
tellraw @s [{"text":"/function fonttester:show/ascii","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/ascii"}},{"text":" - Basic Latin, digits, punctuation, sample sentence","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/latin","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/latin"}},{"text":" - Extended Latin accents, ligatures, multilingual words","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/greek","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/greek"}},{"text":" - Greek uppercase, lowercase, and accented forms","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/cyrillic","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/cyrillic"}},{"text":" - Core Cyrillic alphabet plus common regional letters","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/symbols","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/symbols"}},{"text":" - UI symbols, arrows, operators, and misc signs","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/width_test","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/width_test"}},{"text":" - Narrow vs wide glyphs, ambiguous characters, spacing checks","color":"white"}]
tellraw @s [{"text":"/function fonttester:show/ui_test","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:show/ui_test"}},{"text":" - HUD, menu, button, and status label samples","color":"white"}]
tellraw @s [{"text":"/function fonttester:full","color":"yellow","bold":true,"clickEvent":{"action":"run_command","value":"/function fonttester:full"}},{"text":" - Runs every on-screen preview section in one command","color":"white"}]
tellraw @s {"text":""}
tellraw @s [{"text":"Tip: Place your font resource pack at the top of the list for the most accurate preview.","color":"gray","italic":true}]
tellraw @s [{"text":"Created by ","color":"light_purple","italic":true},{"text":"LevelsFR","color":"light_purple","italic":true,"underlined":true,"clickEvent":{"action":"open_url","value":"https://www.curseforge.com/members/levelsfr/projects"}},{"text":" for the Our Story Collection","color":"light_purple","italic":true}]
tellraw @s [{"text":"Hosted with support from ","color":"light_purple","italic":true},{"text":"BisectHosting","color":"light_purple","italic":true,"underlined":true,"clickEvent":{"action":"open_url","value":"https://www.bisecthosting.com/OurStory"}}]

tellraw @s {"text":"-- Symbols --","color":"yellow","bold":true}
tellraw @s {"text":"â˜… â˜† â™¥ â™  â™£ â™¦ â˜º â˜» â˜¼ â˜½ â˜¾","color":"white"}
tellraw @s {"text":"âœ“ âœ— âœ” âœ˜ â˜‘ â˜’","color":"white"}
tellraw @s {"text":"â† â†‘ â†’ â†“ â†” â†•","color":"white"}
tellraw @s {"text":"Â« Â» â€¹ â€º â€¢ â€¦ â„– â„¢ Â© Â®","color":"white"}
tellraw @s {"text":"Â± Ã— Ã· = â‰  â‰¤ â‰¥ ~","color":"white"}

tellraw @s {"text":"-- Latin Extended --","color":"yellow","bold":true}
tellraw @s {"text":"Ã€ Ã Ã‚ Ãƒ Ã„ Ã… Ã† Ã‡ Ãˆ Ã‰ ÃŠ Ã‹ ÃŒ Ã ÃŽ Ã Ã‘ Ã’ Ã“ Ã” Ã• Ã– Ã˜ Å’ Ã™ Ãš Ã› Ãœ Ã","color":"white"}
tellraw @s {"text":"Ã  Ã¡ Ã¢ Ã£ Ã¤ Ã¥ Ã¦ Ã§ Ã¨ Ã© Ãª Ã« Ã¬ Ã­ Ã® Ã¯ Ã± Ã² Ã³ Ã´ Ãµ Ã¶ Ã¸ Å“ Ã¹ Ãº Ã» Ã¼ Ã½ Ã¿","color":"white"}
tellraw @s {"text":"Ãž Ã¾ Ã Ã° ÃŸ Å Å‚ Å  Å¡ Å½ Å¾ Ä² Ä³","color":"white"}
tellraw @s {"text":"CafÃ© NoÃ«l dÃ©jÃ  vu fiancÃ© SÃ£o TomÃ© Ã…ngstrÃ¶m smÃ¶rgÃ¥s","color":"gray"}

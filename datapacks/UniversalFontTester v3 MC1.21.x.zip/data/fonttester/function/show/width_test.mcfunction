tellraw @s {"text":"-- Width Test --","color":"yellow","bold":true}
tellraw @s {"text":"IIIIIIII  llllllll  11111111  ||||||||","color":"white"}
tellraw @s {"text":"WWWWWWWW  MMMMMMMM  OOOOOOOO  00000000","color":"white"}
tellraw @s {"text":"il1I|!   O0Q   S5   Z2   B8   rn m","color":"white"}
tellraw @s {"text":"....,,,,;;;;::::    ''\"\"``~~","color":"white"}
tellraw @s {"text":"[IIII] [WWWW] [0000] [mmmm] [----]","color":"gray"}
tellraw @s {"text":"Spacing sample: A A A A | i i i i | W W W W | 1 1 1 1","color":"gray"}

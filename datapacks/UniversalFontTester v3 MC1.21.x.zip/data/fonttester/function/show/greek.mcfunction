tellraw @s {"text":"-- Greek --","color":"yellow","bold":true}
tellraw @s {"text":"Î‘ Î’ Î“ Î” Î• Î– Î— Î˜ Î™ Îš Î› Îœ Î Îž ÎŸ Î  Î¡ Î£ Î¤ Î¥ Î¦ Î§ Î¨ Î©","color":"white"}
tellraw @s {"text":"Î± Î² Î³ Î´ Îµ Î¶ Î· Î¸ Î¹ Îº Î» Î¼ Î½ Î¾ Î¿ Ï€ Ï Ïƒ Ï„ Ï… Ï† Ï‡ Ïˆ Ï‰ Ï‚","color":"white"}
tellraw @s {"text":"Î† Îˆ Î‰ ÎŠ ÎŒ ÎŽ Î Î¬ Î­ Î® Î¯ ÏŒ Ï ÏŽ ÏŠ Ï‹ Î Î°","color":"white"}

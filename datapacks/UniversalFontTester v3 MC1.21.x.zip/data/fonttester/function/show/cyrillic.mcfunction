tellraw @s {"text":"-- Cyrillic --","color":"yellow","bold":true}
tellraw @s {"text":"Ð Ð‘ Ð’ Ð“ Ð” Ð• Ð Ð– Ð— Ð˜ Ð™ Ðš Ð› Ðœ Ð Ðž ÐŸ Ð  Ð¡ Ð¢ Ð£ Ð¤ Ð¥ Ð¦ Ð§ Ð¨ Ð© Ðª Ð« Ð¬ Ð­ Ð® Ð¯","color":"white"}
tellraw @s {"text":"Ð° Ð± Ð² Ð³ Ð´ Ðµ Ñ‘ Ð¶ Ð· Ð¸ Ð¹ Ðº Ð» Ð¼ Ð½ Ð¾ Ð¿ Ñ€ Ñ Ñ‚ Ñƒ Ñ„ Ñ… Ñ† Ñ‡ Ñˆ Ñ‰ ÑŠ Ñ‹ ÑŒ Ñ ÑŽ Ñ","color":"white"}
tellraw @s {"text":"Ò Ò‘ Ð„ Ñ” Ð† Ñ– Ð‡ Ñ—","color":"white"}

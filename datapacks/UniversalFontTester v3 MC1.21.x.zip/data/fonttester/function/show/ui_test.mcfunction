tellraw @s {"text":"-- UI Test --","color":"yellow","bold":true}
tellraw @s {"text":"PLAY  OPTIONS  BACK  NEXT  DONE  CANCEL","color":"white"}
tellraw @s {"text":"ON  OFF   ENABLED  DISABLED   LOCKED  READY","color":"white"}
tellraw @s {"text":"HP  MP  XP   LVL 10   COINS 999   SCORE 12345","color":"white"}
tellraw @s {"text":"+12  -4  50%  1.25x  x64  24/64  03:45","color":"white"}
tellraw @s {"text":"Quest Updated   Inventory Full   New Objective","color":"white"}
tellraw @s {"text":"Use this section to judge HUD labels, counters, and buttons.","color":"gray"}

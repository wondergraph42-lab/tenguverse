tellraw @s {"text":"-- ASCII / Basic Latin --","color":"yellow","bold":true}
tellraw @s {"text":"ABCDEFGHIJKLMNOPQRSTUVWXYZ","color":"white"}
tellraw @s {"text":"abcdefghijklmnopqrstuvwxyz","color":"white"}
tellraw @s {"text":"0123456789","color":"white"}
tellraw @s {"text":"! ? . , : ; ( ) [ ] { } - _ + = / \\ | ' \" ` ~ @ # $ % ^ & *","color":"white"}
tellraw @s {"text":"The quick brown fox jumps over the lazy dog.","color":"gray"}

# Better Days Display - Universal Changelog

## v1.1

Better Days Display v1.1 is the first polished public release of the datapack.

### Added

- Day counter displayed in the action bar.
- Per-player survived day tracking.
- Milestone titles for selected survival day thresholds.
- Top survivors function.
- Automatic datapack load and tick integration.

### Improved

- Cleaner internal structure for the datapack.
- More consistent function organization.
- Better separation between initialization, ticking logic, and milestones.
- Improved readability and maintenance compared to the early build.

### Fixed

- General scoreboard consistency issues.
- Safer initialization flow.
- Cleaner handling of survived day tracking.
- Reduced risk of logic conflicts during normal datapack usage.

### Compatibility

- Dedicated release packages were prepared for the Minecraft 1.21.x line.
- Use the zip matching your exact Minecraft version for best compatibility.

### Notes

- This changelog is universal for all Better Days Display v1.1 release packages.
- Version-specific compatibility is handled through separate datapack archives.
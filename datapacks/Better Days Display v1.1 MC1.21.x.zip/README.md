# Better Days Display

Better Days Display is a lightweight Minecraft datapack for 1.21-1.21.1 that tracks survived days per player, shows a day counter in the action bar, and triggers milestone titles at key milestones.

## Version

This workspace currently contains v1.5.

## Main Namespace

The main namespace is `betterdays`.

Compatibility wrappers are still available under `entries` for older commands and older worlds.

## Included Functions

- `/function betterdays:top_days` shows the ranking of connected players.
- `/function betterdays:load` reruns safe pack initialization.
- `/function betterdays:tick` is called automatically by the vanilla tick tag.
- `/function betterdays:settings/open` opens the clickable chat settings menu.
- `/function betterdays:admin/reset_self` resets your own counter for testing.
- `/function betterdays:admin/reset_online` resets all currently online players.

## Settings

The chat settings menu currently supports:

- Global enable or disable for the datapack.
- Always-on day counter in the action bar. Default: enabled.
- Temporary popup when a new day starts. Default: 5 seconds.
- New day animation toggle with digit-by-digit reveal.
- Day label color presets. Default: white.
- Popup duration presets.
- Milestone titles and rewards.

## Technical Notes

- Existing worlds are supported through versioned migrations on load.
- Player state is stored in scoreboard objectives: `temp_day`, `last_day_seen`, `days_survived`, `display_timer`, `animation_timer`, and `display_value`.
- Global pack state is stored in `storage betterdays:state`.
- Persistent settings are stored in `storage betterdays:settings`.
- Milestones are individual functions under `data/betterdays/function/milestones/`.

## Compatibility

- Minecraft 1.21 to 1.21.1
- Existing `entries:*` calls still work through wrappers in v1.5
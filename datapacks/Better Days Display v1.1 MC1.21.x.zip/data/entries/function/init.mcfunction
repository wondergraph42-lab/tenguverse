function betterdays:init

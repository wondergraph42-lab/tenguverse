function betterdays:load

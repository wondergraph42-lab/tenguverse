function betterdays:tick

title @s times 10 60 10
title @s subtitle {"text":"Unlucky? Not for you.","color":"yellow"}
title @s title {"text":"Step Thirteen","color":"gold"}
execute at @s run particle minecraft:campfire_cosy_smoke ~ ~1 ~ 0.2 0.6 0.2 0.03 18
effect give @s minecraft:luck 300

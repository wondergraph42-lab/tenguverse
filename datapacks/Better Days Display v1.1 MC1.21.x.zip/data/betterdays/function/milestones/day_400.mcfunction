title @s times 10 60 10
title @s subtitle {"text":"400 stories written in the dust.","color":"yellow"}
title @s title {"text":"400 Days Survived","color":"gold"}

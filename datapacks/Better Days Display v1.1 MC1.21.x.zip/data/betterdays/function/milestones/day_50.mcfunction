title @s times 10 60 10
title @s subtitle {"text":"Half a century!","color":"gold"}
title @s title {"text":"Day 50","color":"yellow"}
execute at @s run particle minecraft:firework ~ ~1 ~ 0.8 1.2 0.8 0.2 12
effect give @s minecraft:absorption 20 1 true
give @s minecraft:iron_ingot 5

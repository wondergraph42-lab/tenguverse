title @s times 10 60 10
title @s subtitle {"text":"30 days into the wild.","color":"blue"}
title @s title {"text":"Explorer","color":"aqua"}

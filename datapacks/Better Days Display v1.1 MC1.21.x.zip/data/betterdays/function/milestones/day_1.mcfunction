title @s times 10 60 10
title @s subtitle {"text":"Your adventure has just begun.","color":"yellow"}
title @s title {"text":"A Hero's Dawn","color":"gold"}

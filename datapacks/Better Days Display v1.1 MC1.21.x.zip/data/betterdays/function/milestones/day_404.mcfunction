title @s times 10 60 10
title @s subtitle {"text":"Not Found? But you're here!","color":"gray"}
title @s title {"text":"404 Milestone","color":"dark_gray"}
execute at @s run particle minecraft:ash ~ ~1 ~ 0.3 0.2 0.3 0.03 19
effect give @s minecraft:blindness 3 0 true
give @s minecraft:paper[minecraft:custom_name="\"Error 404\""]
playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 1

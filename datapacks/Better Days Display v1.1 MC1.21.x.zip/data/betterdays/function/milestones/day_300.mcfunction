title @s times 10 60 10
title @s subtitle {"text":"300 stories written in the dust.","color":"yellow"}
title @s title {"text":"300 Days Survived","color":"gold"}

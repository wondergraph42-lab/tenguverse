title @s times 10 60 10
title @s subtitle {"text":"900 stories written in the dust.","color":"yellow"}
title @s title {"text":"900 Days Survived","color":"gold"}

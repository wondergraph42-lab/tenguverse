title @s times 10 60 10
title @s subtitle {"text":"The number of the beast...","color":"red"}
title @s title {"text":"666 Days!","color":"dark_red"}
execute at @s run particle minecraft:smoke ~ ~1 ~ 1 1 1 0.05 40
effect give @s minecraft:fire_resistance 66 0 true
playsound minecraft:entity.wither.spawn player @s ~ ~ ~ 1 1

title @s times 10 60 10
title @s subtitle {"text":"100 stories written in the dust.","color":"yellow"}
title @s title {"text":"100 Days Survived","color":"gold"}

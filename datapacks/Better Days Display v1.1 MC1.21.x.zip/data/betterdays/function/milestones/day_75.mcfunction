title @s times 10 60 10
title @s subtitle {"text":"Three-quarters of a century!"}
title @s title {"text":"Day 75","color":"gold"}
execute at @s run particle minecraft:note ~ ~1 ~ 1 1 1 0.1 17
give @s minecraft:emerald

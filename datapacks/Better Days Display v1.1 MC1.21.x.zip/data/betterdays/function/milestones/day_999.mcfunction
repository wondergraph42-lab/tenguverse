title @s times 10 60 10
title @s subtitle {"text":"Almost there...","color":"gray"}
title @s title {"text":"999 Days!","color":"white"}
execute at @s run particle minecraft:soul ~ ~1 ~ 0.7 0.4 0.7 0.08 18
effect give @s minecraft:speed 30 2 true
playsound minecraft:block.note_block.pling player @s ~ ~ ~ 1 1

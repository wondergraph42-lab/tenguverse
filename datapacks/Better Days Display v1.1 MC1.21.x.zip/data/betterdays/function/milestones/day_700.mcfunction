title @s times 10 60 10
title @s subtitle {"text":"700 stories written in the dust.","color":"yellow"}
title @s title {"text":"700 Days Survived","color":"gold"}

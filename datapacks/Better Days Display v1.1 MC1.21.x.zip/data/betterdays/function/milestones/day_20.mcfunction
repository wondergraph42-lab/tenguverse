title @s times 10 60 10
title @s subtitle {"text":"20 days — still alive.","color":"dark_aqua"}
title @s title {"text":"Seasoned","color":"blue"}

title @s times 10 60 10
title @s subtitle {"text":"10 days and counting…","color":"yellow"}
title @s title {"text":"Survivor!","color":"green"}

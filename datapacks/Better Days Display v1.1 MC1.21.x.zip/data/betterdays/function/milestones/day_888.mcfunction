title @s times 10 60 10
title @s subtitle {"text":"Triple Eight – Prosperity!"}
title @s title {"text":"888 Days!","color":"green"}
execute at @s run particle minecraft:note ~ ~1 ~ 1 1 1 0.2 22
give @s minecraft:emerald 8

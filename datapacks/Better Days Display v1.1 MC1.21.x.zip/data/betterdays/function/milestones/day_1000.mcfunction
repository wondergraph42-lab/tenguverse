title @s times 10 60 10
title @s subtitle {"text":"A THOUSAND DAYS! Incredible.","color":"aqua"}
title @s title {"text":"1000 Days!","color":"gold"}
execute at @s run particle minecraft:dragon_breath ~ ~1 ~ 1 1.5 1 0.2 40
effect give @s minecraft:levitation 3 0 true
give @s minecraft:totem_of_undying[minecraft:custom_name="\"Day 1000 Survivor\""]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1

title @s times 10 60 10
title @s subtitle {"text":"A full week! Feeling stronger."}
title @s title {"text":"7 Days Survived!","color":"gold"}
execute at @s run particle minecraft:happy_villager ~ ~1 ~ 0.5 1 0.5 0.2 20
effect give @s minecraft:strength 30 0 true

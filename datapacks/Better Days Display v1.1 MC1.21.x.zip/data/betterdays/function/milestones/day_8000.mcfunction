title @s times 10 60 10
title @s subtitle {"text":"Day 8000: your mark remains.","color":"yellow"}
title @s title {"text":"Beyond Legends","color":"gold"}

title @s times 10 60 10
title @s subtitle {"text":"No secret remains in this world.","color":"yellow"}
title @s title {"text":"The Immortal","color":"gold"}

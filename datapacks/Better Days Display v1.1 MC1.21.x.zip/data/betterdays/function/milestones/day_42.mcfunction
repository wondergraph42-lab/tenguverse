title @s times 10 60 10
title @s subtitle {"text":"To life, the universe, and everything.","color":"yellow"}
title @s title {"text":"The Universal Answer","color":"gold"}
give @s minecraft:writable_book[minecraft:custom_name="\"Meaning Of Life\""]
execute at @s run particle minecraft:end_rod ~ ~1 ~ 0.7 0.5 0.7 0.08 21

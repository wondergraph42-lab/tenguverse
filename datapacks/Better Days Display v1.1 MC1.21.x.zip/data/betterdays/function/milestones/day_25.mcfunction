title @s times 10 60 10
title @s subtitle {"text":"A quarter of a hundred! Nice."}
title @s title {"text":"25 Days Survived!","color":"gold"}
execute at @s run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.15 15
effect give @s minecraft:regeneration 10 1 true
give @s minecraft:golden_apple

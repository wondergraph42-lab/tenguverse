title @s times 10 60 10
title @s subtitle {"text":"Jackpot!","color":"gold"}
title @s title {"text":"777 Days!","color":"yellow"}
execute at @s run particle minecraft:firework ~ ~1 ~ 1 1 1 0.5 17
give @s minecraft:diamond
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1

scoreboard players add @s days_survived 1
scoreboard players operation @s last_day_seen = @s temp_day
execute if data storage betterdays:settings {day_change_popup:1b} store result score @s display_timer run data get storage betterdays:settings popup_duration
execute unless data storage betterdays:settings {day_change_popup:1b} run scoreboard players set @s display_timer 0
execute if data storage betterdays:settings {animation_enabled:1b} run scoreboard players set @s animation_timer 30
execute unless data storage betterdays:settings {animation_enabled:1b} run scoreboard players set @s animation_timer 0
execute if data storage betterdays:settings {milestones_enabled:1b} run function betterdays:check_milestones
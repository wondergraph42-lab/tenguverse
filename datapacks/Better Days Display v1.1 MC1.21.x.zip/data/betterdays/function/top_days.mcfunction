tellraw @a [{"text":"\n--- Top Survivors: Most Days Survived ---\n","color":"gold"}]

execute as @a[scores={days_survived=1..},sort=descending,limit=1] run tellraw @a [{"text":"1. ","color":"yellow"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=1] run tellraw @a [{"text":"2. ","color":"white"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=2] run tellraw @a [{"text":"3. ","color":"white"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=3] run tellraw @a [{"text":"4. ","color":"gray"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=4] run tellraw @a [{"text":"5. ","color":"gray"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=5] run tellraw @a [{"text":"6. ","color":"gray"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]
execute as @a[scores={days_survived=1..},sort=descending,limit=1,skip=6] run tellraw @a [{"text":"7. ","color":"gray"},{"selector":"@s"},{"text":" - ","color":"gray"},{"score":{"name":"@s","objective":"days_survived"}},{"text":" days","color":"white"}]

tellraw @a [{"text":"\nType /function betterdays:top_days to reopen this ranking.\n","color":"gray"}]

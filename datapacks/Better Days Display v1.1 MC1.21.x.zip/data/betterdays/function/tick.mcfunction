function betterdays:ensure_settings
execute if data storage betterdays:settings {enabled:1b} run function betterdays:ensure_players
execute if data storage betterdays:settings {enabled:1b} as @a store result score @s temp_day run time query day
execute if data storage betterdays:settings {enabled:1b} as @a if score @s temp_day > @s last_day_seen run function betterdays:on_new_day
execute if data storage betterdays:settings {enabled:1b,persistent_bar:1b} as @a run function betterdays:show_daybar
execute if data storage betterdays:settings {enabled:1b,persistent_bar:0b,day_change_popup:1b} as @a[scores={display_timer=1..}] run function betterdays:show_daybar
execute if data storage betterdays:settings {enabled:1b,day_change_popup:1b} as @a[scores={display_timer=1..}] run scoreboard players remove @s display_timer 1
execute if data storage betterdays:settings {enabled:1b} as @a[scores={animation_timer=1..}] run scoreboard players remove @s animation_timer 1
execute if data storage betterdays:settings {enabled:0b} as @a run function betterdays:hide_daybar
scoreboard objectives add animation_timer dummy
scoreboard objectives add display_value dummy
scoreboard objectives add betterdays_math dummy
scoreboard players set #10 betterdays_math 10
scoreboard players set #100 betterdays_math 100
scoreboard players set #1000 betterdays_math 1000
scoreboard players set #10000 betterdays_math 10000
execute as @a unless score @s animation_timer matches 0.. run scoreboard players set @s animation_timer 0
execute as @a unless score @s display_value matches 0.. run scoreboard players set @s display_value 0
data modify storage betterdays:state version set value "1.5"
tellraw @a [{"text":"Better Days Display migrated to v1.5 for this world.","color":"green"}]
scoreboard objectives add animation_timer dummy
execute as @a unless score @s animation_timer matches 0.. run scoreboard players set @s animation_timer 0
data modify storage betterdays:state version set value "1.4"
tellraw @a [{"text":"Better Days Display migrated to v1.4 for this world.","color":"green"}]
# Give every online player a safe default state.
execute as @a unless score @s days_survived matches 1.. run scoreboard players set @s days_survived 1
execute as @a unless score @s last_day_seen matches 0.. store result score @s last_day_seen run time query day
execute as @a unless score @s temp_day matches 0.. run scoreboard players set @s temp_day 0
execute as @a unless score @s display_timer matches 0.. run scoreboard players set @s display_timer 0
execute as @a unless score @s animation_timer matches 0.. run scoreboard players set @s animation_timer 0
execute as @a unless score @s display_value matches 0.. run scoreboard players set @s display_value 0
scoreboard players set @s days_survived 1
execute store result score @s last_day_seen run time query day
scoreboard players set @s temp_day 0
scoreboard players set @s display_timer 0
title @s actionbar ""
tellraw @s [{"text":"Better Days Display: your day counter has been reset.","color":"yellow"}]
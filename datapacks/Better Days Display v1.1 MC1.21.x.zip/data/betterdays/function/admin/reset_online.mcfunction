execute as @a run function betterdays:admin/reset_self
tellraw @a [{"text":"Better Days Display: all online player counters have been reset.","color":"red"}]
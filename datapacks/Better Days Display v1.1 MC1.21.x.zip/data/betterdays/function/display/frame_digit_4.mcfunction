scoreboard players operation @s display_value = @s days_survived
execute if score @s days_survived matches 10000.. run scoreboard players operation @s display_value /= #10 betterdays_math
execute if data storage betterdays:settings {day_label_color:"white"} run title @s actionbar [{"text":"Day ","color":"white"},{"score":{"name":"@s","objective":"display_value"}}]
execute if data storage betterdays:settings {day_label_color:"gold"} run title @s actionbar [{"text":"Day ","color":"gold"},{"score":{"name":"@s","objective":"display_value"}}]
execute if data storage betterdays:settings {day_label_color:"aqua"} run title @s actionbar [{"text":"Day ","color":"aqua"},{"score":{"name":"@s","objective":"display_value"}}]
execute if data storage betterdays:settings {day_label_color:"green"} run title @s actionbar [{"text":"Day ","color":"green"},{"score":{"name":"@s","objective":"display_value"}}]
execute if data storage betterdays:settings {day_label_color:"red"} run title @s actionbar [{"text":"Day ","color":"red"},{"score":{"name":"@s","objective":"display_value"}}]
execute unless data storage betterdays:state {initialized:1b} run function betterdays:init
execute if data storage betterdays:state {initialized:1b} unless data storage betterdays:state {version:"1.5"} run function betterdays:migration/v15
function betterdays:ensure_settings
function betterdays:ensure_players
data modify storage betterdays:state version set value "1.5"
tellraw @a [{"text":"Better Days Display v1.5 loaded.","color":"aqua"},{"text":" Use ","color":"gray"},{"text":"/function betterdays:settings/open","color":"yellow"},{"text":" to configure it.","color":"gray"}]
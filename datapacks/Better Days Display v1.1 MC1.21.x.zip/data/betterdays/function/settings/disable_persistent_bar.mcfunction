data modify storage betterdays:settings persistent_bar set value 0b
function betterdays:settings/open
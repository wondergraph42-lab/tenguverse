data modify storage betterdays:settings milestones_enabled set value 0b
function betterdays:settings/open
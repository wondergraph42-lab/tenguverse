data modify storage betterdays:settings day_label_color set value "aqua"
function betterdays:settings/open
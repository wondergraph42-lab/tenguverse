data modify storage betterdays:settings day_label_color set value "red"
function betterdays:settings/open
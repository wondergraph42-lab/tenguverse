data modify storage betterdays:settings day_label_color set value "white"
function betterdays:settings/open
data modify storage betterdays:settings day_label_color set value "green"
function betterdays:settings/open
data modify storage betterdays:settings day_label_color set value "gold"
function betterdays:settings/open
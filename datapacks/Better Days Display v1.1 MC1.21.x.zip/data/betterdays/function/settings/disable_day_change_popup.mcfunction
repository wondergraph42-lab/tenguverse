data modify storage betterdays:settings day_change_popup set value 0b
function betterdays:settings/open
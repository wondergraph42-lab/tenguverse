data modify storage betterdays:settings enabled set value 0b
function betterdays:settings/open
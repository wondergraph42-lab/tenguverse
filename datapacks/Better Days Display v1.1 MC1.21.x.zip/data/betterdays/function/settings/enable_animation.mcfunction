data modify storage betterdays:settings animation_enabled set value 1b
function betterdays:settings/open
data modify storage betterdays:settings day_change_popup set value 1b
function betterdays:settings/open
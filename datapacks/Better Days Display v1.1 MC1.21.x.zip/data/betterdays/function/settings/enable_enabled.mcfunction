data modify storage betterdays:settings enabled set value 1b
function betterdays:settings/open
data modify storage betterdays:settings persistent_bar set value 1b
function betterdays:settings/open
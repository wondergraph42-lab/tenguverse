data modify storage betterdays:settings popup_duration set value 40
function betterdays:settings/open
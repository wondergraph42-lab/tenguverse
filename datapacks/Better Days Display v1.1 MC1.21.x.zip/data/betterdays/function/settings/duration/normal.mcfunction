data modify storage betterdays:settings popup_duration set value 100
function betterdays:settings/open
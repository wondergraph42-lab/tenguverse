data modify storage betterdays:settings popup_duration set value 200
function betterdays:settings/open
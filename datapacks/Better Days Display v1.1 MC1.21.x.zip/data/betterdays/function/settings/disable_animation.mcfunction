data modify storage betterdays:settings animation_enabled set value 0b
function betterdays:settings/open
# One-time scoreboard bootstrap guarded by storage.
scoreboard objectives add temp_day dummy
scoreboard objectives add last_day_seen dummy
scoreboard objectives add days_survived dummy
scoreboard objectives add display_timer dummy
scoreboard objectives add animation_timer dummy
scoreboard objectives add display_value dummy
scoreboard objectives add betterdays_math dummy
scoreboard players set #10 betterdays_math 10
scoreboard players set #100 betterdays_math 100
scoreboard players set #1000 betterdays_math 1000
scoreboard players set #10000 betterdays_math 10000

data modify storage betterdays:state initialized set value 1b
data modify storage betterdays:state version set value "1.5"
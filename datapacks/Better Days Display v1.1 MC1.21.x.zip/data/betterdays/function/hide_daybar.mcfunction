title @s actionbar ""
scoreboard players set @s display_timer 0
scoreboard players set @s animation_timer 0
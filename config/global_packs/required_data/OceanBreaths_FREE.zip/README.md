# OceanBreaths
A Minecraft datapack to add some ways to live under the oceans, breathing bubbles and chimney's oxygen.

# Requires 
- Minecraft 1.21+

# Use
1. Download the package
2. Copy/paste the entire "OceanBreaths/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.

# Developer infos
Hooks are called on bubble and chimney air refill. Create those functions to add your own code into the loop.
- as PLAYER at @s anchored eyes: function #minecraft:oceanbreaths/on_bubble_consume
- as PLAYER at @s anchored eyes: function #minecraft:oceanbreaths/on_chimney_consume

# Author
- Name: FunkyToc 
- Website: https://funkytoc.fr
- PMC: https://www.planetminecraft.com/member/funkytoc/
- Modrinth: https://modrinth.com/user/FunkyToc

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks
My Patreons that buy me coffe every days.
My community wich reminds me that I'm lazy.
Minecraft community in general, that gives meaning to this project.

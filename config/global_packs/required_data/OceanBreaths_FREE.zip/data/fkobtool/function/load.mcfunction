# scores
scoreboard objectives add fktool dummy

# fkversion
scoreboard players set #FktoolVersion fktool 12100
execute store success score #tmp fktool run function fkobtool:fkversion
scoreboard players reset #FktoolVersion fktool
execute if score #tmp fktool matches 0 run return run tellraw @a[tag=fkdev] [{"text":"[fktool] exit: error during update","color":"red"}]

# init
function fkobtool:utils/set_constants
function fkobtool:difficulty/get
function fkobtool:mcv/get
function fkobtool:rng/get
function fkobtool:warnings/get

# modules
#function fkobtool:systime/get

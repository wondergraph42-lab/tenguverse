execute if score McVersion fktool matches 12005.. as @a[predicate=fkobtool:entity/standing/in_water_feet] at @s align y run function fkob:tick_compat

schedule function fkob:tick 5s

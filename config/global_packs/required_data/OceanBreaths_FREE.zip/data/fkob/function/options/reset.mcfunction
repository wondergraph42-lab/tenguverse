scoreboard players set Bubble fkob.options 1
scoreboard players set BubbleMultiplier fkob.options 2
data modify storage fkob:options Bubble.O2 set value 20
scoreboard players set Chimney fkob.options 1
scoreboard players set ChimneyMultiplier fkob.options 2
data modify storage fkob:options Chimney.O2 set value 30
scoreboard players set Trail fkob.options 1

tellraw @s ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold"},{"text":"Options have been reset","color":"red"}]

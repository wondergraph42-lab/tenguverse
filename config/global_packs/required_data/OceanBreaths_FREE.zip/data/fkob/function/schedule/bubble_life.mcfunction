execute as @e[type=minecraft:marker,tag=fkob.bubble.prepare] at @s run function fkob:systems/bubble/prepare
execute as @e[type=minecraft:marker,tag=fkob.bubble.pop] at @s run function fkob:systems/bubble/pop
execute as @a[gamemode=!spectator] at @s anchored eyes positioned ^ ^ ^ if predicate fkobtool:entity/standing/in_water_feet if entity @e[type=minecraft:marker,tag=fkob.bubble.pop,distance=..1.5] run function fkob:systems/bubble/consume

execute if entity @e[type=minecraft:marker,tag=fkob.bubble] run schedule function fkob:schedule/bubble_life 5t replace

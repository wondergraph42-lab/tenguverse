# display fx & die
execute as @e[type=minecraft:marker,tag=fkob.trail] at @s run function fkob:systems/trail/life

# add trail particle
execute if score Compat_Vanilla fkob.options matches 1 as @a[gamemode=!spectator,predicate=fkobtool:entity/standing/in_water_full] at @s if predicate fkob:compatibility/vanilla_oceans if predicate fkob:ocean_ground run summon minecraft:marker ~ ~ ~ {Tags:["fkob.trail"]}
execute if score Compat_Terralith fkob.options matches 1 as @a[gamemode=!spectator,predicate=fkobtool:entity/standing/in_water_full] at @s if predicate fkob:compatibility/terralith_oceans if predicate fkob:ocean_ground run summon minecraft:marker ~ ~ ~ {Tags:["fkob.trail"]}

execute if entity @e[type=minecraft:marker,tag=fkob.trail,limit=1] run schedule function fkob:schedule/trail_life 6t replace

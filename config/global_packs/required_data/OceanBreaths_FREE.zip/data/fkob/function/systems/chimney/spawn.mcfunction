summon minecraft:marker ~ ~-.5 ~ {Tags:["fkob.entity","fkob.chimney","fkob.chimney.pop"]}
execute as @e[type=minecraft:marker,tag=fkob.chimney,distance=..1,limit=1,sort=nearest] at @s run function fkob:systems/chimney/transform
schedule function fkob:schedule/chimney_life 2s append

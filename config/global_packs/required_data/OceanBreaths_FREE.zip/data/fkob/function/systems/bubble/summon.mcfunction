# summon chance
execute if predicate fkob:bubble_chance rotated ~-80 0 positioned ^ ^ ^18 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~-60 0 positioned ^ ^ ^20 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~-40 0 positioned ^ ^ ^22 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~-20 0 positioned ^ ^ ^25 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~000 0 positioned ^ ^ ^25 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~020 0 positioned ^ ^ ^25 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~040 0 positioned ^ ^ ^22 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~060 0 positioned ^ ^ ^20 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
execute if predicate fkob:bubble_chance rotated ~080 0 positioned ^ ^ ^18 run summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}

# randomize pos
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^ ^ ^03
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^ ^ ^-3
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^03 ^ ^
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^-3 ^ ^
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^ ^03 ^
execute as @e[type=minecraft:marker,tag=fkob.bubble.init,limit=3,sort=random] if predicate fkobtool:rng/50 at @s facing entity @p[gamemode=!spectator] eyes run tp @s ^ ^-3 ^

# check
execute as @e[type=minecraft:marker,tag=fkob.bubble.init] at @s run function fkob:systems/bubble/init

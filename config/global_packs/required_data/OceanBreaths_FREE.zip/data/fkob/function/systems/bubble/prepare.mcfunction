execute unless predicate fkobtool:entity/standing/in_water_feet run return run function fkob:systems/bubble/transform
tp @s ~ ~-.4 ~

execute unless predicate fkobtool:entity/standing/in_water_eye run return run kill @s
particle minecraft:bubble_column_up ~ ~.3 ~ .3 .2 .3 .001 5
tp @s ~ ~.3 ~

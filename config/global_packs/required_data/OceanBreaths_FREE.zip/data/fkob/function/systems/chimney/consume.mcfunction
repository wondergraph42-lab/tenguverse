execute positioned ^ ^-.2 ^.6 run particle minecraft:bubble_pop ~ ~ ~ .1 .1 .1 .01 1

function fkob:systems/chimney/get_air with storage fkob:options Chimney
function #minecraft:oceanbreaths/on_chimney_consume

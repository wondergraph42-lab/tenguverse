execute positioned ^ ^-.2 ^.6 run particle minecraft:bubble_pop ~ ~ ~ .1 .1 .1 .01 10
playsound minecraft:entity.player.swim player @a[predicate=fkobtool:entity/standing/in_water_eye,distance=..16] ~ ~ ~ .5 .5 .01
playsound minecraft:block.pointed_dripstone.drip_water_into_cauldron player @a[predicate=fkobtool:entity/standing/in_water_eye,distance=..16] ~ ~ ~ 3 .5 .01

function fkob:systems/bubble/get_air with storage fkob:options Bubble
function #minecraft:oceanbreaths/on_bubble_consume

kill @e[type=minecraft:marker,tag=fkob.bubble.pop,distance=..2.5,sort=nearest,limit=1]

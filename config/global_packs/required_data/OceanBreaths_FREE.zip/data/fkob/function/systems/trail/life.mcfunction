particle minecraft:campfire_cosy_smoke ~ ~ ~ .1 .05 .1 .001 1
kill @s
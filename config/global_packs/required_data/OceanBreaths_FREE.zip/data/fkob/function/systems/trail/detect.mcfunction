execute if predicate fkob:ocean_ground run schedule function fkob:schedule/trail_life 10t append

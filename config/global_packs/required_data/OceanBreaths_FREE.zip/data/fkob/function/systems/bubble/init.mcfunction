execute unless predicate fkobtool:entity/standing/in_water_feet run kill @s
execute if score Compat_Vanilla fkob.options matches 1 unless predicate fkob:compatibility/vanilla_oceans run kill @s
execute if score Compat_Terralith fkob.options matches 1 unless predicate fkob:compatibility/terralith_oceans run kill @s
tag @s remove fkob.bubble.init

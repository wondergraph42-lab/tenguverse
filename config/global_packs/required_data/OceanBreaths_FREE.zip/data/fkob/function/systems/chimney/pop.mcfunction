particle minecraft:bubble_column_up ~ ~ ~ .08 .1 .08 .001 3
particle minecraft:dust_plume ~ ~.2 ~ .1 .05 .1 0 1
particle minecraft:white_smoke ~ ~.2 ~ .08 .02 .08 0 3

# check destroyed
execute if block ~ ~ ~ minecraft:water run setblock ~ ~1 ~ minecraft:water
execute if block ~ ~ ~ minecraft:water run kill @s
execute unless block ~ ~1 ~ minecraft:light run setblock ~ ~ ~ minecraft:water
execute unless block ~ ~1 ~ minecraft:light run kill @s

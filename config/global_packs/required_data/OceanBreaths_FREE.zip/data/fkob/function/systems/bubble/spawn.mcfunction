summon minecraft:marker ~ ~ ~ {Tags:["fkob.entity","fkob.bubble","fkob.bubble.prepare","fkob.bubble.init"]}
#execute as @e[type=minecraft:marker,tag=fkob.bubble.init,distance=..1,limit=1,sort=nearest] at @s run function fkob:systems/bubble/init
schedule function fkob:schedule/bubble_life 2s append

scoreboard objectives add fkob.options dummy {"text":"OceanBreaths Options","color":"#008058"}

function fkob:properties
function fkob:schedule/list
schedule function fkob:compatibility 21t

tellraw @a ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Enabled. "},{"text":"See all projects on "},{"text":"PMC","color":"#3366cc","clickEvent":{"action":"open_url","value":"https://www.planetminecraft.com/member/funkytoc/submissions/"}},{"text":" or "},{"text":"Modrinth","color":"#1bd96a","clickEvent":{"action":"open_url","value":"https://modrinth.com/user/FunkyToc"}},{"text":"!"}]
execute if score McVersion fktool matches ..12006 run tellraw @a ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Version 1.20.6 or inferior detected. This datapack needs 1.21+.","color":"red"}]
execute if score McVersion fktool matches 12100.. run tellraw @a ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"Modify Options "},{"text":"[click here]","bold":true,"color":"aqua","clickEvent":{"action":"suggest_command","value":"/function fkob:options/get"}}]
execute if score McVersion fktool matches 12100.. run tellraw @a ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold","hoverEvent":{"action":"show_text","value":[{"text":"Developed with love by "},{"text":"FunkyToc","color":"#8269ff","bold":true}]}},{"text":"You're playing the FREE version, get the customizable version "},{"text":"[becoming a Patreon]","bold":true,"color":"aqua","clickEvent":{"action":"open_url","value":"https://www.patreon.com/funkytoc"}}]
tellraw @a[tag=fkdev] [{"text":"Loaded with McVersion -> ","color":"red"},{"score":{"name":"McVersion","objective":"fktool"},"color":"gray"}]

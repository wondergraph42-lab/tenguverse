execute as @e[type=minecraft:marker,tag=fkob.chimney] at @s run function fkob:systems/chimney/remove
kill @e[type=minecraft:marker,tag=fkob.bubble]
kill @e[type=minecraft:marker,tag=fkob.chimney]

scoreboard players reset * fkob.options
scoreboard objectives remove fkob.options

give @s minecraft:command_block[custom_name='{"color":"#AF91FF","italic":false,"text":"Ocean Breaths: Entity Remover"}',lore=['{"color":"white","italic":false,"text":"Hide this command_block at your spawn for fiew days."}','{"color":"white","italic":false,"text":"It will kill possible remaining entities (bubbles and chimneys)."}','{"color":"red","italic":false,"text":"Change into \\"Repeat & Always Active\\" mode, or build a redstone loop."}'],block_entity_data={id:"minecraft:repeating_command_block",TrackOutput:1b,powered:1b,auto:0b,CustomName:'{"color":"#AF91FF","italic":false,"text":"Ocean Breaths Entity Remover"}',Command:"kill @e[type=minecraft:marker,tag=fkob.entity]"}]

function fkobtool:uninstall

datapack disable "file/OceanBreaths.zip"
datapack disable "file/OceanBreaths_FREE.zip"

tellraw @s ["",{"text":"[OceanBreaths] ","bold":true,"color":"gold"},{"text":"Uninstalled","color":"red"}]
